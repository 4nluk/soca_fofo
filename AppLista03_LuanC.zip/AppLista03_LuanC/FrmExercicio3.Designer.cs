﻿namespace AppLista03_LuanC
{
    partial class FrmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblExercicio3 = new System.Windows.Forms.Label();
            this.pnlWhit = new System.Windows.Forms.Panel();
            this.lblRefeicaoKg = new System.Windows.Forms.Label();
            this.lblResultRef = new System.Windows.Forms.Label();
            this.btnCalcRef = new System.Windows.Forms.Button();
            this.txtPesoRef = new System.Windows.Forms.TextBox();
            this.pnlWhit.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblExercicio3
            // 
            this.lblExercicio3.AutoSize = true;
            this.lblExercicio3.Font = new System.Drawing.Font("Verdana", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExercicio3.Location = new System.Drawing.Point(229, 40);
            this.lblExercicio3.Name = "lblExercicio3";
            this.lblExercicio3.Size = new System.Drawing.Size(317, 59);
            this.lblExercicio3.TabIndex = 2;
            this.lblExercicio3.Text = "Exercicio 3";
            // 
            // pnlWhit
            // 
            this.pnlWhit.BackColor = System.Drawing.SystemColors.HighlightText;
            this.pnlWhit.Controls.Add(this.lblExercicio3);
            this.pnlWhit.Location = new System.Drawing.Point(0, -7);
            this.pnlWhit.Name = "pnlWhit";
            this.pnlWhit.Size = new System.Drawing.Size(809, 143);
            this.pnlWhit.TabIndex = 3;
            // 
            // lblRefeicaoKg
            // 
            this.lblRefeicaoKg.AutoSize = true;
            this.lblRefeicaoKg.Font = new System.Drawing.Font("Verdana", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRefeicaoKg.Location = new System.Drawing.Point(130, 202);
            this.lblRefeicaoKg.Name = "lblRefeicaoKg";
            this.lblRefeicaoKg.Size = new System.Drawing.Size(264, 32);
            this.lblRefeicaoKg.TabIndex = 4;
            this.lblRefeicaoKg.Text = "Peso da refeição";
            // 
            // lblResultRef
            // 
            this.lblResultRef.AutoSize = true;
            this.lblResultRef.Font = new System.Drawing.Font("Verdana", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultRef.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lblResultRef.Location = new System.Drawing.Point(281, 373);
            this.lblResultRef.Name = "lblResultRef";
            this.lblResultRef.Size = new System.Drawing.Size(234, 38);
            this.lblResultRef.TabIndex = 12;
            this.lblResultRef.Text = "RESULTADO";
         //   this.lblResultRef.Click += new System.EventHandler(this.lblResultRef_Click);
            // 
            // btnCalcRef
            // 
            this.btnCalcRef.Font = new System.Drawing.Font("Verdana", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcRef.Location = new System.Drawing.Point(306, 286);
            this.btnCalcRef.Name = "btnCalcRef";
            this.btnCalcRef.Size = new System.Drawing.Size(183, 67);
            this.btnCalcRef.TabIndex = 11;
            this.btnCalcRef.Text = "CALCULAR";
            this.btnCalcRef.UseVisualStyleBackColor = true;
            this.btnCalcRef.Click += new System.EventHandler(this.btnCalcRef_Click);
            // 
            // txtPesoRef
            // 
            this.txtPesoRef.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(23)))));
            this.txtPesoRef.Location = new System.Drawing.Point(417, 209);
            this.txtPesoRef.Name = "txtPesoRef";
            this.txtPesoRef.Size = new System.Drawing.Size(216, 20);
            this.txtPesoRef.TabIndex = 9;
            // 
            // FrmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Crimson;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblResultRef);
            this.Controls.Add(this.btnCalcRef);
            this.Controls.Add(this.txtPesoRef);
            this.Controls.Add(this.lblRefeicaoKg);
            this.Controls.Add(this.pnlWhit);
            this.Name = "FrmExercicio3";
            this.Text = "FrmExercicio3";
            this.pnlWhit.ResumeLayout(false);
            this.pnlWhit.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblExercicio3;
        private System.Windows.Forms.Panel pnlWhit;
        private System.Windows.Forms.Label lblRefeicaoKg;
        private System.Windows.Forms.Label lblResultRef;
        private System.Windows.Forms.Button btnCalcRef;
        private System.Windows.Forms.TextBox txtPesoRef;
    }
}