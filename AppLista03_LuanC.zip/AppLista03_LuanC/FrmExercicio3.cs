﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03_LuanC
{
    public partial class FrmExercicio3 : Form
    {
        public FrmExercicio3()
        {
            InitializeComponent();
        }

        private void btnCalcRef_Click(object sender, EventArgs e)
        {
            float pesoRefDef = float.Parse(txtPesoRef.Text);
            float vlrRef;
            vlrRef = pesoRefDef * 34;
            lblResultRef.Text = "O valor da refeição é:" + vlrRef + "R$!";
        }
    }
}
