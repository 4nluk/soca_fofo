﻿namespace AppLista03_LuanC
{
    partial class FrmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblExercicio2 = new System.Windows.Forms.Label();
            this.pnlHeader = new System.Windows.Forms.Panel();
            this.lblValor = new System.Windows.Forms.Label();
            this.lblGasolinaV = new System.Windows.Forms.Label();
            this.txtValorG = new System.Windows.Forms.TextBox();
            this.txtLitroG = new System.Windows.Forms.TextBox();
            this.btnCalc = new System.Windows.Forms.Button();
            this.lblResult = new System.Windows.Forms.Label();
            this.pnlHeader.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblExercicio2
            // 
            this.lblExercicio2.AutoSize = true;
            this.lblExercicio2.BackColor = System.Drawing.Color.Transparent;
            this.lblExercicio2.Font = new System.Drawing.Font("Verdana", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExercicio2.ForeColor = System.Drawing.Color.White;
            this.lblExercicio2.Location = new System.Drawing.Point(235, 54);
            this.lblExercicio2.Name = "lblExercicio2";
            this.lblExercicio2.Size = new System.Drawing.Size(317, 59);
            this.lblExercicio2.TabIndex = 1;
            this.lblExercicio2.Text = "Exercicio 2";
            // 
            // pnlHeader
            // 
            this.pnlHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(11)))), ((int)(((byte)(18)))));
            this.pnlHeader.Controls.Add(this.lblExercicio2);
            this.pnlHeader.Location = new System.Drawing.Point(0, -12);
            this.pnlHeader.Name = "pnlHeader";
            this.pnlHeader.Size = new System.Drawing.Size(811, 146);
            this.pnlHeader.TabIndex = 2;
            // 
            // lblValor
            // 
            this.lblValor.AutoSize = true;
            this.lblValor.Font = new System.Drawing.Font("Verdana", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValor.ForeColor = System.Drawing.Color.Snow;
            this.lblValor.Location = new System.Drawing.Point(126, 184);
            this.lblValor.Name = "lblValor";
            this.lblValor.Size = new System.Drawing.Size(201, 25);
            this.lblValor.TabIndex = 3;
            this.lblValor.Text = "VALOR A PAGAR";
            // 
            // lblGasolinaV
            // 
            this.lblGasolinaV.AutoSize = true;
            this.lblGasolinaV.Font = new System.Drawing.Font("Verdana", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGasolinaV.ForeColor = System.Drawing.Color.Snow;
            this.lblGasolinaV.Location = new System.Drawing.Point(126, 248);
            this.lblGasolinaV.Name = "lblGasolinaV";
            this.lblGasolinaV.Size = new System.Drawing.Size(301, 25);
            this.lblGasolinaV.TabIndex = 4;
            this.lblGasolinaV.Text = "VALOR LITRO GASOLINA";
            // 
            // txtValorG
            // 
            this.txtValorG.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(23)))));
            this.txtValorG.Location = new System.Drawing.Point(443, 184);
            this.txtValorG.Name = "txtValorG";
            this.txtValorG.Size = new System.Drawing.Size(216, 20);
            this.txtValorG.TabIndex = 5;
            // 
            // txtLitroG
            // 
            this.txtLitroG.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(23)))));
            this.txtLitroG.Location = new System.Drawing.Point(443, 248);
            this.txtLitroG.Name = "txtLitroG";
            this.txtLitroG.Size = new System.Drawing.Size(216, 20);
            this.txtLitroG.TabIndex = 6;
            this.txtLitroG.TextChanged += new System.EventHandler(this.txtLitroG_TextChanged);
            // 
            // btnCalc
            // 
            this.btnCalc.Font = new System.Drawing.Font("Verdana", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalc.Location = new System.Drawing.Point(299, 298);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(183, 67);
            this.btnCalc.TabIndex = 7;
            this.btnCalc.Text = "CALCULAR";
            this.btnCalc.UseVisualStyleBackColor = true;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // lblResult
            // 
            this.lblResult.AutoSize = true;
            this.lblResult.Font = new System.Drawing.Font("Verdana", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResult.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lblResult.Location = new System.Drawing.Point(270, 385);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(234, 38);
            this.lblResult.TabIndex = 8;
            this.lblResult.Text = "RESULTADO";
            // 
            // FrmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(23)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.btnCalc);
            this.Controls.Add(this.txtLitroG);
            this.Controls.Add(this.txtValorG);
            this.Controls.Add(this.lblGasolinaV);
            this.Controls.Add(this.lblValor);
            this.Controls.Add(this.pnlHeader);
            this.Name = "FrmExercicio2";
            this.Text = "FrmExercicio2";
            this.pnlHeader.ResumeLayout(false);
            this.pnlHeader.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblExercicio2;
        private System.Windows.Forms.Panel pnlHeader;
        private System.Windows.Forms.Label lblValor;
        private System.Windows.Forms.Label lblGasolinaV;
        private System.Windows.Forms.TextBox txtValorG;
        private System.Windows.Forms.TextBox txtLitroG;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.Label lblResult;
    }
}