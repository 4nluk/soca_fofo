﻿namespace Bug22
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.txtN1 = new System.Windows.Forms.TextBox();
            this.txtN2 = new System.Windows.Forms.TextBox();
            this.btnMOSTRAR = new System.Windows.Forms.Button();
            this.lblN1 = new System.Windows.Forms.Label();
            this.lblN2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtN1
            // 
            this.txtN1.Location = new System.Drawing.Point(228, 144);
            this.txtN1.Name = "txtN1";
            this.txtN1.Size = new System.Drawing.Size(371, 20);
            this.txtN1.TabIndex = 0;
            this.txtN1.TextChanged += new System.EventHandler(this.txtN1_TextChanged);
            // 
            // txtN2
            // 
            this.txtN2.Location = new System.Drawing.Point(228, 188);
            this.txtN2.Name = "txtN2";
            this.txtN2.Size = new System.Drawing.Size(371, 20);
            this.txtN2.TabIndex = 1;
            // 
            // btnMOSTRAR
            // 
            this.btnMOSTRAR.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMOSTRAR.Location = new System.Drawing.Point(228, 234);
            this.btnMOSTRAR.Name = "btnMOSTRAR";
            this.btnMOSTRAR.Size = new System.Drawing.Size(371, 64);
            this.btnMOSTRAR.TabIndex = 2;
            this.btnMOSTRAR.Text = "MOSTRAR";
            this.btnMOSTRAR.UseVisualStyleBackColor = true;
            this.btnMOSTRAR.Click += new System.EventHandler(this.btnMOSTRAR_Click);
            // 
            // lblN1
            // 
            this.lblN1.AutoSize = true;
            this.lblN1.BackColor = System.Drawing.Color.Transparent;
            this.lblN1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblN1.ForeColor = System.Drawing.Color.Snow;
            this.lblN1.Location = new System.Drawing.Point(193, 143);
            this.lblN1.Name = "lblN1";
            this.lblN1.Size = new System.Drawing.Size(29, 18);
            this.lblN1.TabIndex = 3;
            this.lblN1.Text = "N1";
            // 
            // lblN2
            // 
            this.lblN2.AutoSize = true;
            this.lblN2.BackColor = System.Drawing.Color.Transparent;
            this.lblN2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblN2.ForeColor = System.Drawing.Color.Snow;
            this.lblN2.Location = new System.Drawing.Point(193, 188);
            this.lblN2.Name = "lblN2";
            this.lblN2.Size = new System.Drawing.Size(29, 18);
            this.lblN2.TabIndex = 4;
            this.lblN2.Text = "N2";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Bug22.Properties.Resources.JiCDk;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblN2);
            this.Controls.Add(this.lblN1);
            this.Controls.Add(this.btnMOSTRAR);
            this.Controls.Add(this.txtN2);
            this.Controls.Add(this.txtN1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtN1;
        private System.Windows.Forms.TextBox txtN2;
        private System.Windows.Forms.Button btnMOSTRAR;
        private System.Windows.Forms.Label lblN1;
        private System.Windows.Forms.Label lblN2;
    }
}

